package com.example.myexsd;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity implements FragmentOne.ColorSender{

    TabLayout tabLayout1;
    ViewPager viewPager1;
    ViewPagerAdapter viewPagerAdapter1;
    int col;
    static FragmentOne.ColorSender CS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager1 = findViewById(R.id.viewPager1);
        viewPagerAdapter1 = new ViewPagerAdapter(getSupportFragmentManager());
        viewPager1.setAdapter(viewPagerAdapter1);
        tabLayout1 = findViewById(R.id.tabs1);
        tabLayout1.setupWithViewPager(viewPager1);

        Toast.makeText(getApplicationContext(),"Use options Menu to switch between questions",Toast.LENGTH_LONG).show();
    }


    @Override
    public void sendColor(int c) {
        col=c;
        String tag = "android:switcher:" + R.id.viewPager1 + ":" + 1;
        FragmentTwo f = (FragmentTwo) getSupportFragmentManager().findFragmentByTag(tag);
        assert f != null;
        f.displayColor(c);
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences sharedPreferences = getSharedPreferences("MyColor", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        myEdit.putInt("defc",col);
        myEdit.putBoolean("frst",true);
        myEdit.apply();
        Toast.makeText(getApplicationContext(),"Color stored",Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sp=getSharedPreferences("MyColor",MODE_PRIVATE);
        FragmentTwo.kno=sp.getBoolean("frst",false);
        FragmentTwo.b=sp.getInt("defc", 0);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_p2,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.p2_p4:startActivity(new Intent(getApplicationContext(),StoreFile.class));
                break;
            case R.id.p2_p5:
                startActivity(new Intent(getApplicationContext(),MulFrag.class));
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}