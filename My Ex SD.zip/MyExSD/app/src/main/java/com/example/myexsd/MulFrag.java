package com.example.myexsd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.tabs.TabLayout;

public class MulFrag extends AppCompatActivity implements FragOne2.AreaC, FragTwo2.CostC {

    TabLayout tabLayout2;
    ViewPager viewPager2;
    ViewPagerAdapter2 viewPagerAdapter2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mul_frag);
        viewPager2 = findViewById(R.id.viewPager2);
        viewPagerAdapter2 = new ViewPagerAdapter2(getSupportFragmentManager());
        viewPager2.setAdapter(viewPagerAdapter2);
        tabLayout2 = findViewById(R.id.tabs2);
        tabLayout2.setupWithViewPager(viewPager2);

        getSupportActionBar().setTitle("P5 Multiple Fragments");
    }


    @Override
    public void areaCalc(int x) {
        String tag = "android:switcher:" + R.id.viewPager2 + ":" + 1;
        FragTwo2 f = (FragTwo2) getSupportFragmentManager().findFragmentByTag(tag);
        assert f != null;
        f.dispArea(x);
    }

    @Override
    public void findC(int x) {
        String tag = "android:switcher:" + R.id.viewPager2 + ":" + 2;
        FragThree2 f = (FragThree2) getSupportFragmentManager().findFragmentByTag(tag);
        assert f != null;
        f.dispC(x);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_p5,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.p5_p2:startActivity(new Intent(getApplicationContext(),MainActivity.class));
                break;
            case R.id.p5_p4:startActivity(new Intent(getApplicationContext(),StoreFile.class));
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
