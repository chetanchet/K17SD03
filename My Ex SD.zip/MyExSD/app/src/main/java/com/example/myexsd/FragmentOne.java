package com.example.myexsd;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import static android.content.Context.MODE_PRIVATE;

public class FragmentOne extends Fragment {

    RadioGroup rg;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_one, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rg=view.findViewById(R.id.rg);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                Toast.makeText(getContext(),"Swipe right to see color",Toast.LENGTH_SHORT).show();
                switch(i){
                    case R.id.rb1:MainActivity.CS.sendColor(Color.RED);
                        break;
                    case R.id.rb2:MainActivity.CS.sendColor(Color.BLUE);
                        break;
                    case R.id.rb3:MainActivity.CS.sendColor(Color.GREEN);
                        break;
                    case R.id.rb4:MainActivity.CS.sendColor(Color.parseColor("#d2691e"));
                        break;
                    case R.id.rb5:MainActivity.CS.sendColor(Color.YELLOW);
                        break;
                    case R.id.rb6:MainActivity.CS.sendColor(Color.parseColor("#ffc0cb"));
                        break;
                    case R.id.rb7:MainActivity.CS.sendColor(Color.parseColor("#551a8b"));
                        break;
                    case R.id.rb8:MainActivity.CS.sendColor(Color.parseColor("#7f00ff"));
                        break;
                    case R.id.rb9:MainActivity.CS.sendColor(Color.BLACK);
                        break;
                    case R.id.rb0:MainActivity.CS.sendColor(Color.GRAY);
                        break;

                }
            }
        });
    }

    interface ColorSender {
        void sendColor(int c);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            MainActivity.CS = (ColorSender) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException("Error in retrieving data. Please try again");
        }
    }

}