package com.example.myexsd;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FragOne2 extends Fragment {
    EditText et1,et2,et3;
    Button b1;
    AreaC o;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root= inflater.inflate(R.layout.fragment_frag_one2, container, false);
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        et1=view.findViewById(R.id.et1);
        et2=view.findViewById(R.id.et2);
        et3=view.findViewById(R.id.et3);
        b1=view.findViewById(R.id.btc1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int l,b,h;
                l=Integer.parseInt(et1.getText().toString());
                b=Integer.parseInt(et2.getText().toString());
                h=Integer.parseInt(et3.getText().toString());
                try {
                    o.areaCalc(2 * (l * b + b * h + h * l));
                    Toast.makeText(getContext(),"swipe right for surface area",Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    interface AreaC{
        public void areaCalc(int x);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            o = (AreaC) getActivity();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
